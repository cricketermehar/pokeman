# KinanCity Modernized Platform & Automation Suite
## Final Delivery Package for Jason (`jasonhere1`)

**Version:** 2.1.19-SNAPSHOT  
**Build Target:** Java 17 (LTS) & Python 3.9+  
**Operating Systems:** Windows 10/11 & macOS  
**Delivery Date:** October 2026  

---

## 1. Directory Structure

```
KinanCity_Final_Delivery/
│
├── KinanCity-Source/                  ← Complete multi-module Java source code
│   ├── KinanCity-core/
│   ├── KinanCity-mail/
│   ├── ptc-api/
│   ├── KinanCity-captcha-*/
│   └── pom.xml
│
├── Build/                             ← Standalone compiled fat JAR packages
│   ├── kinancity-core-2.1.19-SNAPSHOT.jar
│   ├── kinancity-mail-2.1.19-SNAPSHOT.jar
│   └── kinancity-captcha-server-2.1.19-SNAPSHOT.jar
│
├── python-automation/                 ← Python queue & state machine automation
│   ├── accounts.txt.example           ← Template for account credentials
│   ├── accounts.txt                   ← [GITIGNORED] user credentials (username:password)
│   ├── queue_state.json               ← [GITIGNORED] auto-saved state machine resume file
│   ├── config.ini                     ← Non-secret configuration
│   ├── account_queue.py               ← Queue manager & accounts.txt parser
│   ├── account_record.py              ← AccountRecord dataclass & AccountState enum
│   ├── state_machine.py               ← Per-account lifecycle state engine
│   ├── credential_store.py            ← Secure credential loader (zero secrets in logs)
│   ├── ptc_investigator.py            ← Read-only PTC flow probe & report generator
│   ├── mail_watcher.py                ← Bridge between KinanCity-mail & queue
│   ├── retry_handler.py               ← Exponential backoff retry handler
│   ├── run_logger.py                  ← Structured JSON logger
│   ├── preview.py                     ← Live web preview dashboard (http://localhost:8080)
│   │
│   ├── adapters/
│   │   ├── ugphone_driver.py          ← Real ADB and in-memory simulated drivers
│   │   └── ugphone_adapter.py         ← UGPhone & PGTools cloud Android automation engine
│   │
│   └── tests/                         ← 39 passing unit tests
│       ├── test_account_queue.py
│       ├── test_credential_store.py
│       ├── test_ptc_investigator.py
│       ├── test_state_machine.py
│       └── test_ugphone_adapter.py
│
├── Documentation/                     ← Full engineering documentation
│   ├── PROJECT_MEMORY.md              ← Master context & takeover guide
│   ├── KINANCITY_ARCHITECTURE.md      ← System architecture & Mermaid flow diagrams
│   ├── KINANCITY_MODERNIZATION_REPORT.md ← Full changelog & bug fixes
│   ├── MODERNIZATION_NOTES.md         ← Technical root causes (OkHttp, MIME, logging)
│   ├── SETUP_AND_RUN.md               ← Windows 11 / Mac setup & build guide
│   └── PTC_REGISTRATION_INVESTIGATION.md ← Live investigation of PTC endpoints & Akamai
│
└── README.md                          ← THIS FILE
```

---

## 2. Key Accomplishments & Deliverables

### ✅ 1. Java 17 Build Restoration
* **Multi-Module Maven Build:** Fully restored and passing across all 14 modules (`mvn clean test` and `mvn clean package`).
* **Resolved Dependency Conflicts:** Eliminated duplicate and conflicting OkHttp 2.x/3.x/4.x versions causing classpath collisions.
* **Modernized Compiler:** Configured for Java 17 LTS compatibility.

### ✅ 2. Security & Redaction Hardening
* Replaced plaintext password logging in CLI arguments, proxy URLs, and session logs with `[MASKED]` / `[PROTECTED]`.
* Passwords are never written to `queue_state.json` or run logs; they remain strictly in the user-provided `accounts.txt`.

### ✅ 3. KinanCity-mail Embedded SMTP Server
* Fixed single-part (`text/plain`) and multipart MIME parsing in `KcMessageHandler.java` to prevent `ClassCastException`.
* Updated activation link regex to capture modern PTC URL formats.
* Verified live on SMTP port `2525` with real email reception and activation link extraction.

### ✅ 4. Python Automation Backend
* **Resumable Queue:** Order-preserving, crash-resilient account queue.
* **State Machine:** Tracks complete lifecycle (`QUEUED` → `ACTIVE` → `PGTOOLS_READY` → `POWERUP` → `COMPLETED`).
* **UGPhone & PGTools Adapter:** Automates Candy checks, lowest-CP sorting (to conserve Stardust), power-up execution, and quest reward claiming.
* **Live Dashboard:** Single-command web preview UI at `http://localhost:8080` (`python preview.py`).
* **39 / 39 Unit Tests Passing:** In ~0.3 seconds.

---

## 3. Quickstart & Verification Guide

### Step 1: Run Python Automated Tests (39 Tests)
```bash
cd python-automation
python3 -m unittest discover -s tests -v
```
*Expected: All 39 tests pass with `OK`.*

### Step 2: Run PGTools Automation Simulation
```bash
cd python-automation
python3 main.py --dry-run --ugphone
```
*Expected: Processes accounts through the simulated cloud phone, sorts by lowest CP, completes power-ups, claims rewards, and marks accounts `COMPLETED` in `queue_state.json`.*

### Step 3: Run the Live Web Preview Dashboard
```bash
cd python-automation
python3 preview.py
```
*Open your browser at [http://localhost:8080](http://localhost:8080) to see live metrics, queue status, and engine logs.*

### Step 4: Run the Local KinanCity-mail Server
```bash
# In Windows cmd / PowerShell / Terminal:
java -jar Build/kinancity-mail-2.1.19-SNAPSHOT.jar
```
*Listens on SMTP port 2525 and writes extracted activation links to `links.log`.*

---

## 4. PTC Registration Status (Akamai Blocker)

* **Direct Legacy Registration:** `https://club.pokemon.com/us/pokemon-trainer-club/sign-up/` now redirects (`HTTP 302`) to `trainer.pokemon.com` and is protected by **Akamai Bot Manager** JavaScript challenges (`<script src="/Pearkd-him-hithinock-my-dulour-pronor-to-make-th" async></script>`).
* Direct HTTP POST requests without browser fingerprints return **`HTTP 403 Forbidden`**.
* As agreed in Phase 1, automated bulk account generation through these protections requires an active CapSolver/2Captcha API key, rotating residential proxies, and a stealth browser engine (Playwright Stealth).
* Detailed probe results are available in **`Documentation/PTC_REGISTRATION_INVESTIGATION.md`**.
