import * as fs from 'fs';
import * as path from 'path';
import { loadConfig } from '../config/environment';
import { BrowserService } from '../core/browser.service';
import { RetryManager } from '../core/retry.manager';
import { CaptchaService } from '../services/captcha.service';
import { EmailVerificationService } from '../services/email.service';
import { RegistrationService } from '../services/registration.service';
import { MockMailboxAdapter } from '../adapters/mock-mailbox.adapter';
import { WorkflowOrchestrator } from '../runner';
import { logger } from '../core/logger.service';

interface BatchAccountSpec {
  username: string;
  password: string;
  email: string;
}

async function runBatch(count: number = 5) {
  console.log('════════════════════════════════════════════════════════════');
  console.log(`  KinanCity Automated Sandbox Batch Creator (${count} Accounts)`);
  console.log('════════════════════════════════════════════════════════════\n');

  const baseConfig = loadConfig();
  const testServerOrigin = new URL(baseConfig.TEST_TARGET_URL).origin;

  const browserService = new BrowserService(baseConfig);
  await browserService.initialize();

  const retryManager = new RetryManager({
    maxRetries: 2,
    baseDelayMs: 500,
  });

  const captchaService = new CaptchaService(baseConfig.OPERATOR_TIMEOUT_MS, 500, true);
  const registrationService = new RegistrationService(captchaService);
  const mailboxAdapter = new MockMailboxAdapter(testServerOrigin);

  const results: Array<{
    index: number;
    username: string;
    email: string;
    success: boolean;
    durationSeconds: string;
    error?: string;
  }> = [];

  const createdFile = path.resolve('created_accounts.txt');

  const accountsToCreate: BatchAccountSpec[] = Array.from({ length: count }, (_, i) => {
    const id = (i + 1).toString().padStart(2, '0');
    const randomSuffix = Math.random().toString(36).substring(2, 6);
    return {
      username: `AutoUser${id}${randomSuffix}`,
      password: `AutoPass${id}!99`,
      email: `autouser${id}_${randomSuffix}@example.com`,
    };
  });

  try {
    for (let i = 0; i < accountsToCreate.length; i++) {
      const spec = accountsToCreate[i];
      const accountConfig = {
        ...baseConfig,
        TEST_ACCOUNT_USERNAME: spec.username,
        TEST_ACCOUNT_PASSWORD: spec.password,
        TEST_ACCOUNT_EMAIL: spec.email,
        OPERATOR_TIMEOUT_MS: 5000,
      };

      const emailService = new EmailVerificationService(mailboxAdapter, accountConfig);
      const orchestrator = new WorkflowOrchestrator(
        browserService,
        registrationService,
        emailService,
        retryManager,
        accountConfig
      );

      console.log(`▶ [${i + 1}/${count}] Creating Account: ${spec.username} (${spec.email})...`);
      const startTime = Date.now();
      const outcome = await orchestrator.run();
      const durationSeconds = ((Date.now() - startTime) / 1000).toFixed(2);

      if (outcome.success) {
        console.log(`  ✅ Successfully created and activated in ${durationSeconds}s!\n`);
        fs.appendFileSync(createdFile, `${spec.username}:${spec.password}:${spec.email}\n`, 'utf-8');
      } else {
        console.log(`  ❌ Failed: ${outcome.error} (${durationSeconds}s)\n`);
      }

      results.push({
        index: i + 1,
        username: spec.username,
        email: spec.email,
        success: outcome.success,
        durationSeconds,
        error: outcome.error,
      });

      // Brief delay between accounts
      await new Promise((res) => setTimeout(res, 800));
    }
  } finally {
    await browserService.teardown();
  }

  console.log('════════════════════════════════════════════════════════════');
  console.log('  BATCH CREATION SUMMARY');
  console.log('════════════════════════════════════════════════════════════');
  console.table(
    results.map((r) => ({
      '#': r.index,
      Username: r.username,
      Email: r.email,
      Status: r.success ? '✅ ACTIVATED' : '❌ FAILED',
      Duration: `${r.durationSeconds}s`,
    }))
  );

  const successfulCount = results.filter((r) => r.success).length;
  console.log(`\nTotal Successfully Activated: ${successfulCount} / ${count}`);
  console.log(`Saved credentials to: ${createdFile}\n`);
}

if (require.main === module) {
  const countArg = parseInt(process.argv[2] || '5', 10);
  const count = isNaN(countArg) || countArg <= 0 ? 5 : countArg;
  runBatch(count).catch((err) => {
    console.error('Batch creator failed:', err);
    process.exit(1);
  });
}
